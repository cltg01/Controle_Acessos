
        
        <h3 class="azul text-dark">Controle de Acessos</h3>
        <p class="text-white">Olá, <?php echo $_SESSION['usuNome']; ?></p>

        <nav class="navbar navbar-expand-lg navbar-dark fundo-navegacao borda-redonda">
            <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
                <div class="navbar-nav">
                    <a class="nav-link" href="index.php?action=inicio&control=administracao">Início</a>
                    <span class="nav-link text-White"><b>|</b></span>
                    <a class="nav-link text-White" href="index.php?action=usuarios&control=usuario">Usuários</a>
                    <span class="nav-link text-White"><b>|</b></span>
                    <a class="nav-link ttext-White" href="index.php?action=unidades&control=unidade">Unidades</a>
                    <span class="nav-link text-White"><b>|</b></span>
                    <a class="nav-link text-White" href="index.php?action=portarias&control=portaria">Portarias</a>
                    <span class="nav-link text-White"><b>|</b></span>
                    <a class="nav-link text-White" href="index.php?action=crachas&control=cracha">Vouchers</a>
                    <span class="nav-link text-White"><b>|</b></span>
                    <a class="nav-link text-White" href="index.php?action=empresas&control=empresa">Empresas</a>
                    <span class="nav-link text-White"><b>|</b></span>
                    <a class="nav-link text-White" href="index.php?action=novo&control=relatorio">Relatório</a>
                    <span class="nav-link text-White"><b>|</b></span>
                    <a class="nav-link text-White" href="index.php?action=logout">Sair</a>
                </div>
            </div>
        </nav>
        <h4 style="margin-top:5px"><?php echo $titulo; ?></h4>