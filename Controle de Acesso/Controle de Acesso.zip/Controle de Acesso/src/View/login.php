<!DOCTYPE html>
<html>
<?php
include('./html/head.php');
?>

<body data-page="login">
    <div class="container">
        <div class="form-container sign-in">
            <form method="post" action="index.php?action=login">
                <div class="form-group">
                    <label for="login">Usuário</label>
                    <input type="text" id="login" name="login" size="30px" class="form-control" required autofocus>
                </div>
                <div class="form-group">
                    <label for="senha">Senha</label>
                    <input type="password" id="senha fundo-senha" name="senha" size="30px" class="form-control" required>
                </div>
                <div class="text-center">
                    <input type="submit" value="Entrar" class="btn botao">
                </div>
            </form>
            <?php
            $regra = 'danger';
            include_once('./html/mensagem.php');
            ?>
        </div>
        <div class="toggle-container">
            <div class="toggle">
                <div class="toggle-panel toggle-right">
                    <blockquote class="blockquote">
                        <p class="mb-0">Eu sou parte de uma equipe. Então, quando venço, não sou eu apenas quem vence.
                            De certa forma termino o trabalho de um grupo enorme de pessoas!</p>
                        <footer class="blockquote-footer text-white">Ayrton Senna</footer>
                    </blockquote>
                </div>
            </div>
        </div>

    </div>


    </div>
    <?php include('./html/scriptsjs.php'); ?>
</body>

</html>